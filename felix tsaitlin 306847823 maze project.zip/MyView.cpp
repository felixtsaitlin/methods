#include "MyView.h"
#include "Controller.h"

using namespace std;
MyView::MyView(std::istream& is, std::ostream& os)
	:_is(is), _os(os)
{
}
	
MyView::~MyView()
{
}

void MyView::put(string data)
{
	_os << data;
}

string MyView::getStr()
{
	string val;
	_is >> val;
	return val;
}

int MyView::getInt()
{
	int val;
	_is >> val;
	return val;
}

void MyView::showCommands(vector<string> commandsVec)
{
	_os << "Commands are: ";
	for (int i = 0; i < commandsVec.size(); i++)
	{
		_os << commandsVec[i];
		if (i < commandsVec.size() - 1)
			_os << ", ";
		else
			_os << ".";
	}
	_os << endl;
	_os << "please insert your command" << endl;
}

void MyView::start()
{
	if (!_controller) {
		_os << "Controller not set. Press any key to exit" << endl;
		_is.get();
		return;
	}

	string cmdStr;
	
	vector<string> commandsVec = _controller->getCommandNames();

	showCommands(commandsVec);
	_is >> cmdStr;

	while (cmdStr.compare("Exit") != 0)
	{
		Command* cmd = _controller->getCommand(cmdStr);
		if (cmd != nullptr)
			cmd->execute();
		else
			_os << "commande does not exist" << endl;

		showCommands(commandsVec);
		_is >> cmdStr;
	}

	_os << "goodbye. press any key to continue..." << endl;
	_is.get();
}


void MyView::update(string message)
{
	_os << message << endl;
}

void MyView::displayMaze(Maze2d* m) const
{
	if(m)
		_os << *m << endl;
}

ostream& MyView::getOstream()
{
	return _os;
}
