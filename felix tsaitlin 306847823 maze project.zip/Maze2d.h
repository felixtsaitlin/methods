#pragma once

#include <algorithm>
#include "Maze2dImpl.h"


//proxy class for Maze2dImpl and its derivatives

class Maze2d
{
private:
	Maze2dImpl* _pMaze;	 
public:
	Maze2d();
	Maze2d(Maze2dImpl* pMaze);
	Maze2d(std::vector<int> dataVec);
	Position getStartPosition() const;
	Position getEndPosition() const;
	std::vector<Position> getPossibleMoves(Position p) const;
	int getHeight() const;
	int getWidth() const;
	friend std::ostream& operator<<(std::ostream& o, const Maze2d& m);
	bool isBlocked(Position pos, CellDirection dir) const;
	bool isUnBlocked(Position pos, CellDirection dir) const;
	bool isValidPos(Position pos) const;
	const int** getOneZeroGrid() const;
	std::vector<int> getData() const;

};


