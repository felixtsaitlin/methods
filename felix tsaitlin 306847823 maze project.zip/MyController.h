#pragma once

#include <map>
#include "Controller.h"
#include "MyModel.h"
#include "MyView.h"

class MyController : public Controller
{
protected:
	std::map<std::string, Command*> _commandsMap;
public:
	MyController(Model* model, View* view);
	~MyController();
	virtual Command* getCommand(std::string cmdName);
	virtual void update(std::string message) override;
	virtual std::vector<std::string> getCommandNames() override;

};

