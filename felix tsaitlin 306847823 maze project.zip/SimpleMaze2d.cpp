#include "SimpleMaze2d.h"

using namespace std;
SimpleMaze2d::SimpleMaze2d(int h, int w)
	:Maze2dImpl()
{
	//TODO
}

SimpleMaze2d::~SimpleMaze2d()
{
	//TODO
}





