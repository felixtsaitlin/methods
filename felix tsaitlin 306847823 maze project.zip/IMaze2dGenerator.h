#pragma once
#include "Maze2d.h"
#include <string>

class IMaze2dGenerator
{
public:
	virtual Maze2d generate(int w, int h) = 0;
	virtual std::string measureAlgorithmTime() = 0;
};

