#include "MyMaze2d.h"
#include "Position.h"
#include <ctime>
#include <vector>
#include <string>
using namespace std;

MyMaze2d::MyMaze2d(vector<int> data)
{
	_height = data[0];
	_width = data[1];

	//create grid
	_grid = new int*[_height];

	for (int i = 0; i < _height; i++)
	{
		_grid[i] = new int[_width];
	}

	_startPos.setRow(data[2]);
	_startPos.setCol(data[3]);
	_endPos.setRow(data[4]);
	_endPos.setCol(data[5]);
	//fill the grid
	int r = 0;
	int c = 0;

	for (int i = 6; i < data.size(); i++)
	{
		_grid[r][c] = data[i];
		c++;
		if (c == _width)
		{
			c = 0;
			r++;
		}
	}
}

void MyMaze2d::fillWallsRec(stack<Position>& posStack, int** maze, int& nVisited, int height, int width)
{
	//generate the maze

	if (nVisited >= width * height)
	{
		return;
	}
	else
	{
		//create unvisited neighbours vec
		vector<int> neighbours;
		Position p = posStack.top();

		//check up
		if (p.getRow() > 0 && (maze[p.getRow() - 1][p.getCol()] & CELL_VISITED) == 0x00)
			neighbours.push_back(0);
		//check right
		if (p.getCol() < width - 1 && (maze[p.getRow()][p.getCol() + 1] & CELL_VISITED) == 0x00)
			neighbours.push_back(1);
		//check down
		if (p.getRow() < height - 1 && (maze[p.getRow() + 1][p.getCol()] & CELL_VISITED)== 0x00)
			neighbours.push_back(2);
		//check left
		if (p.getCol() > 0 && (maze[p.getRow()][p.getCol() -1] & CELL_VISITED) == 0x00)
			neighbours.push_back(3);

		//check if unvisited neighbours exist
		if (neighbours.size() > 0)
		{
			int nextMove = neighbours[rand() % neighbours.size()];
			
			//connect them
			switch (nextMove)
			{
			case 0: //up
				maze[p.getRow()][p.getCol()] |= PATH_UP;
				maze[p.getRow() - 1][p.getCol()] |= PATH_DOWN;
				posStack.push(Position(p.getRow() - 1, p.getCol()));
				break;
			case 1: //right
				maze[p.getRow()][p.getCol()] |= PATH_RIGHT;
				maze[p.getRow()][p.getCol() + 1] |= PATH_LEFT;
				posStack.push(Position(p.getRow(), p.getCol() + 1));
				break;
			case 2: //down
				maze[p.getRow()][p.getCol()] |= PATH_DOWN;
				maze[p.getRow() + 1][p.getCol()] |= PATH_UP;
				posStack.push(Position(p.getRow() + 1, p.getCol()));
				break;
			case 3: //left
				maze[p.getRow()][p.getCol()] |= PATH_LEFT;
				maze[p.getRow()][p.getCol() - 1] |= PATH_RIGHT;
				posStack.push(Position(p.getRow(), p.getCol() - 1));
				break;
			}
			maze[posStack.top().getRow()][posStack.top().getCol()] |= CELL_VISITED;
			nVisited++;
		}
		else
		{
			posStack.pop();
		}
		fillWallsRec(posStack,maze,nVisited,height,width);
	}
}

MyMaze2d::MyMaze2d(int width, int height)
	//:_width(width),_height(height)
{
	height = height / 2;
	width = width / 2;
	int** _bitWallsMaze;
	Position startPos;
	Position endPos;
	int _nVisited;
	//init the maze

	_bitWallsMaze = new int*[height];
	stack<Position> posStack;

	for (int r = 0; r < height; r++)
	{
		_bitWallsMaze[r] = new int[width];
		memset(_bitWallsMaze[r], 0, width * sizeof(int));
	}

	//randomally choose start and end pos
	srand(time(NULL));
	startPos.setRow(rand() % height);
	startPos.setCol(rand() % width);

	endPos.setRow(rand() % height);
	endPos.setCol(rand() % width);
	while (startPos == endPos)
	{
		endPos.setRow(rand() % height);
		endPos.setCol(rand() % width);
	}

	posStack.push(startPos);
	_bitWallsMaze[startPos.getRow()][startPos.getCol()] = CELL_VISITED;
	_nVisited = 1;

	//generate the maze
	fillWallsRec(posStack, _bitWallsMaze, _nVisited, height, width);
	generateOneZeroGrid(_bitWallsMaze, height, width);
	
	//set the start and end pos for the 1 and 0 maze
	_height = height * 2 + 1;
	_width = width * 2 + 1;
	_startPos.setRow(startPos.getRow() * 2 + 1);
	_startPos.setCol(startPos.getCol() * 2 + 1);
	_endPos.setRow(endPos.getRow() * 2 + 1);
	_endPos.setCol(endPos.getCol() * 2 + 1);

	for (int r = 0; r < height; r++)
	{
		delete[] _bitWallsMaze[r];
	}

	delete[] _bitWallsMaze;
}

MyMaze2d::~MyMaze2d()
{
	for (int r = 0; r < _height; r++)
	{
		delete[] _grid[r];
	}

	delete[] _grid;
}



void MyMaze2d::generateOneZeroGrid(int** bitWallsMap, int bitWallsH, int bitWallsW)
{
	int h = bitWallsH * 2 + 1;
	int w = bitWallsW * 2 + 1;
	_grid = new int*[h];

	//create grid and fill top and left walls
	for (int i = 0; i < h; i++)
	{
		_grid[i] = new int[w];
		for (int j = 0; j < w; j++)
		{
			if (i % 2 == 0 || j % 2 == 0)
				_grid[i][j] = 0;
			else
				_grid[i][j] = 1;
		}
	}

	//fill the inside walls 
	for (int i = 0; i < bitWallsH; i++)
	{
		for (int j = 0; j < bitWallsW; j++)
		{
			if ((bitWallsMap[i][j] & PATH_RIGHT) != 0x00)
			{
				_grid[i * 2 + 1][(j + 1) * 2] = 1;
			}
			if ((bitWallsMap[i][j] & PATH_DOWN) != 0x00)
			{
				_grid[(i + 1) * 2][j * 2 + 1] = 1;
			}
		}
	}
}
