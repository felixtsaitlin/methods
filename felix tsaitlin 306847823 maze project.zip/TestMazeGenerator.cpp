
#include <string>
#include <iostream>
#include "TestMazeGenerator.h"
#include "Position.h"
#include "AStar.h"

using namespace std;

TestMazeGenerator::TestMazeGenerator()
{
}

TestMazeGenerator::~TestMazeGenerator()
{
}

void TestMazeGenerator::testMazeGenerator(Maze2dGenerator& mg)
{
	//prints the time...
	cout << mg.measureAlgorithmTime() << endl;

	//generate another 2d maze
	Maze2d maze = mg.generate(10,10);

	//get the maze entrance
	Position p = maze.getStartPosition();

	//print the position - format (x,y)
	cout << p << endl;

	cout << maze << endl;
	
	//get all the possible moves from a poistion
	vector<Position> moves = maze.getPossibleMoves(p);

	for (Position move : moves)
		cout << move << endl;

	cout << maze.getEndPosition() << endl;

	cout << maze << endl;

	maze.getOneZeroGrid();

	AstarAirDistHeuristic h1;
	AStar astar1(h1);
	Solution path1 = astar1.search(maze);
	cout << endl << "the path is:" << endl;
	cout << path1;

	AstarManhattanHeuristic h2;
	AStar astar2(h2);
	Solution path2 = astar2.search(maze);
	cout << endl << "the path is:" << endl;
	cout << path2;
}

