#include "searcher.h"

using namespace std;
Searcher::Searcher()
	:_numNodesEveluated(0)
{
}