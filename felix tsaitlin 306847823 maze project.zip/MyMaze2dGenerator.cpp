#include "MyMaze2dGenerator.h"
#include "MyMaze2d.h"

MyMaze2dGenerator::MyMaze2dGenerator()
{
}

MyMaze2dGenerator::~MyMaze2dGenerator()
{
}

Maze2d MyMaze2dGenerator::generate(int w, int h)
{
	return new MyMaze2d(w,h); // Maze2d has a ctor that gets Maze2dImpl* as an argument
}
