#pragma once

#include <iostream>
#include <vector>
#include "State.h"
#include "Position.h"

class Solution
{
private:
	std::vector<State*> _vecStates;
public:
	Solution();
	Solution(std::vector<Position> posVec);
	Solution(const Solution& o);
	const Solution& operator=(const Solution& o);

	~Solution();
	std::vector<State*> getStates() const;
	void add(State* s);
	std::ostream& write(std::ostream& o) const;
};

std::ostream& operator<<(std::ostream& o, const Solution& s);






