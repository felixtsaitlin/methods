#include <iostream>
#include <memory>

#include "aStar.h"
#include "MyMaze2d.h"
#include "MyMaze2dGenerator.h"
#include "SimpleMaze2d.h"
#include "simpleMaze2dGenerator.h"
#include "TestMazeGenerator.h"
#include "MazeCompression.h"
#include "MyView.h"
#include "MyModel.h"
#include "MyController.h"
#include "SearchableMaze.h"

using namespace std;

int main(int argc, char** argv)
{
	MyView myView(cin,cout);
	MyModel myModel;
	MyController myController(&myModel, &myView);
	myView.start();
	return 0;
}