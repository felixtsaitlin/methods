#include "MyModel.h"
#include "MyMaze2dGenerator.h"
#include <filesystem>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <fstream>
#include <cstdio>

using namespace std;
MyModel::MyModel()
{
	_mazeGenerator = new MyMaze2dGenerator();
	_mazeCompression = new MazeCompression();
	_aStarH = new AstarManhattanHeuristic();
	_aStar = new AStar(*_aStarH);
}

MyModel::~MyModel()
{
	delete _mazeGenerator;
	delete _mazeCompression;

	for (int i = 0; i < _filenamesVec.size(); i++)
	{
		remove(_filenamesVec[i].c_str());
	}
	delete _aStar;
}

vector<string> MyModel::dirContents(string path)
{
	vector<string> res;
	std::experimental::filesystem::directory_iterator dirItr(path);
	for (const auto& entry : dirItr)
	{
		res.push_back(entry.path().string());
	}
	if (res.size() == 0)
		notifyObservers("No files in this path.");
	return res;
}

void MyModel::generateMaze(string name, int height, int width)
{
	string msg;
	if (height > MAX_MAZE_HEIGHT || width > MAX_MAZE_WIDTH ||
		height < MIN_MAZE_HEIGHT || width < MIN_MAZE_WIDTH)
	{
		msg = "Cannot create '";
		msg += name.c_str();
		msg += "'. Maze dimenstions are illegal (width ";
		msg += std::to_string(MIN_MAZE_WIDTH);
		msg += "-";
		msg += std::to_string(MAX_MAZE_WIDTH);
		msg += ", height ";
		msg += std::to_string(MIN_MAZE_HEIGHT);
		msg += "-";
		msg += std::to_string(MAX_MAZE_HEIGHT);
		msg += ").";

	}
	else if(_mazesMap.find(name) != _mazesMap.end())
	{
		msg = "Cannot create '";
		msg += name.c_str();
		msg += "'. A maze with the same name already exists.";
	}
	else
	{
		_mazesMap[name] = _mazeGenerator->generate(width,height);
		msg = "Maze '"; 
		msg += name.c_str();
		msg += "' created.";
	}
	notifyObservers(msg);
}

Maze2d* MyModel::displayMaze(string name)
{
	if (_mazesMap.find(name) == _mazesMap.end())
	{
		notifyObservers("Cannot find this maze.");
		return nullptr;
	}
	else
		return &(_mazesMap[name]);
}

void MyModel::saveMaze(string mazeName, string fileName)
{
	string msg;
	
	if (_mazesMap.find(mazeName) == _mazesMap.end())
	{
		msg = "Cannot save '";
		msg += mazeName.c_str();
		msg += "'. I don't have such a maze.";
	}
	else
	{
		ofstream ofs;

		try {
			ofs.open(fileName, ios::binary | ios::out);
			_mazeCompression->save(ofs, _mazesMap.find(mazeName)->second);
			_filenamesVec.push_back(fileName);

			msg = "Maze '";
			msg += mazeName.c_str();
			msg += "' saved successfully.";
		}
		catch (string& s)
		{
			msg = s;
		}
		catch (...)
		{
			msg = "Unknown error while saving to file.";
		}
	}
	notifyObservers(msg);
}

void MyModel::loadMaze(string fileName, string mazeName)
{
	string msg;
	if (_mazesMap.find(mazeName) != _mazesMap.end())
	{
		msg = "Cannot create '";
		msg += mazeName.c_str();
		msg += "' from file. A maze with the same name already exists.";
	}
	else if (std::find(_filenamesVec.begin(), _filenamesVec.end(),fileName) == _filenamesVec.end())
	{
		msg = "Cannot create '";
		msg += mazeName.c_str();
		msg += "' from file. This file does not exist.";
	}
	else
	{
		ifstream ifs;

		try {
			ifs.open(fileName, ios::binary | ios::in);
			Maze2d* m = _mazeCompression->read(ifs);
			_mazesMap[mazeName] = *m;

			msg = "Maze '";
			msg += mazeName.c_str();
			msg += "' read succesfully.";
		}
		catch (string& s)
		{
			msg = s;
		}
		catch (...)
		{
			msg = "Unknown error while saving to file.";
		}
	}
	notifyObservers(msg);
}

int MyModel::mazeSize(string name)
{
	string msg;
	if (_mazesMap.find(name) == _mazesMap.end())
	{
		msg = "Maze '";
		msg += name.c_str();
		msg += "' not exists.";
		notifyObservers(msg);
		return 0;
	}
	else
	{
		return sizeof(int) * (4 + _mazesMap[name].getHeight()*_mazesMap[name].getWidth());
	}
}

int MyModel::fileSize(string name)
{
	string msg;
	if (std::find(_filenamesVec.begin(), _filenamesVec.end(), name) == _filenamesVec.end())
	{
		msg = "File '";
		msg += name.c_str();
		msg += "' not exists.";
		notifyObservers(msg);
		return 0;
	}
	else
	{
		ifstream in(name, ifstream::ate | ifstream::binary);
		return in.tellg();
	}
}

void MyModel::SolveMaze(string name, string algo)
{
	string msg;

	if (_mazesMap.find(name) == _mazesMap.end())
	{
		msg = "Cannot solve '";
		msg += name;
		msg += "'. The masze is not exists.";
	}
	else if (_solutionsMap.find(name) != _solutionsMap.end())
	{
		msg = "We already have a solution for '";
		msg += name;
		msg += "'.";
	}
	else if (algo.compare("AStar") == 0)
	{
		Solution sol = _aStar->search(_mazesMap[name]);
		_solutionsMap[name] = sol;
		msg = "Added solution for maze '";
		msg += name.c_str();
		msg += "'.";
	}
	else
	{
		msg = "Illegal algo name '";
		msg += algo;
		msg += "'. Choose AStar";
	}
	notifyObservers(msg);
}

Solution* MyModel::displaySolution(string name)
{
	string msg;
	if (_solutionsMap.find(name) == _solutionsMap.end())
	{
		msg = "We dont have a solution for '";
		msg += name;
		msg += "'.";
		notifyObservers(msg);
		return nullptr;
	}
	return &(_solutionsMap[name]);
}

void MyModel::ExitClean()
{
	delete _aStarH;
	delete _aStar;
	delete _mazeCompression;
	delete _mazeGenerator;

	for (int i = 0; i < _filenamesVec.size(); i++)
	{
		std::remove(_filenamesVec[i].c_str());
	}
}