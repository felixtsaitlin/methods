#pragma once
#include "Maze2dGenerator.h"

class TestMazeGenerator
{
public:
	TestMazeGenerator();
	~TestMazeGenerator();
	void testMazeGenerator(Maze2dGenerator& mg);
};

