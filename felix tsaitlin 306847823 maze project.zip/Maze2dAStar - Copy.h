#pragma once
#include <iostream>
#include <vector>
#include <stack>
#include <set>
#include "Maze2d.h"

#define COL 1000

// A structure to hold the neccesary parameters 
struct cell
{
    // Row and Column index of its parent 
    // Note that 0 <= i <= ROW-1 & 0 <= j <= COL-1 
    int parent_i, parent_j;
    // f = g + h 
    double f, g, h;
};

//TODO - use class Position instead of pair
// Creating a shortcut for int, int pair type 
typedef std::pair<int, int> Pair;

// Creating a shortcut for pair<int, pair<int, int>> type 
typedef std::pair<double, std::pair<int, int>> pPair;

class MazeAStar
{
private:
	const Maze2d* _pMaze;
public:
	MazeAStar(const Maze2d& m);
	bool isValid(int row, int col);
	bool isUnBlocked(Position& p);
	bool isDestination(Position& p, Position& dest);
	double calculateHValue(int row,int col, Position& dest);
	void tracePath(cell cellDetails[][COL], Position& dest);
	void aStarSearch(Position& src, Position& dest);
};