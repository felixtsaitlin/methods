#include "Position.h"

using namespace std;

ostream& operator<< (ostream& o, const Position& p)
{
	o << "(" << p.getRow() << "," << p.getCol() << ")";
	return o;
}

Position::Position(int row, int col)
	:_row(row),_col(col)
{
}

Position::~Position()
{
}

bool Position::operator==(const Position& o)
{
	return (this->_col == o._col && this->_row == o._row);
}

