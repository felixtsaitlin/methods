#include "Solution.h"

using namespace std;
std::ostream& operator<<(std::ostream& o, const Solution& s)
{
	s.write(o);
	return o;
}

Solution::Solution()
{
}

Solution::Solution(const Solution& o)
{
	State* prevState = nullptr;
	State* currState;
	for (int i = 0; i < o._vecStates.size(); i++)
	{
		currState = new State(o._vecStates[i]->getState(),
			o._vecStates[i]->getCost(), prevState);
		_vecStates.push_back(currState);
		prevState = currState;
	}
}

const Solution& Solution::operator=(const Solution& o)
{
	if (this == &o)
		return *this;

	for (int i = 0; i < _vecStates.size(); i++)
	{
		delete _vecStates[i];
	}

	_vecStates.resize(0);

	State* prevState = nullptr;
	State* currState;
	for (int i = 0; i < o._vecStates.size(); i++)
	{
		currState = new State(o._vecStates[i]->getState(),
			o._vecStates[i]->getCost(), prevState);
		_vecStates.push_back(currState);
		prevState = currState;
	}
	return *this;
}

Solution::Solution(vector<Position> posVec)
{
	State* prevState = nullptr;
	State* currState;
	for (int i = 0; i < posVec.size(); i++)
	{
		currState = new State(posVec[i], i, prevState);
		add(currState);
		prevState = currState;
	}
}

Solution::~Solution()
{
	for (int i = 0; i < _vecStates.size(); i++)
	{
		delete _vecStates[i];
	}
}

vector<State*> Solution::getStates() const
{
	return _vecStates;
}

void Solution::add(State* s)
{
	_vecStates.push_back(s);
}

ostream& Solution::write(ostream& o) const
{
	o << "Solution: { ";
	if (_vecStates.size() == 0)
	{
		o << "This solution set is empty";
	}
	else
	{
		for (int i = 0; i < _vecStates.size(); i++)
		{
			o << *(_vecStates[i]);
			if (i < _vecStates.size() - 1)
				o << " -> ";
		}
	}

	o << " }";
	return o;
}