#pragma once
#include "Command.h"
class CommandSaveToFile :public Command
{
public:
	CommandSaveToFile(Model* m, View* v);
	~CommandSaveToFile();
	virtual void execute() override;
};

