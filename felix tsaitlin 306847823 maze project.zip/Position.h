#pragma once
#include <iostream>

class Position
{
private:
	int _row;
	int _col;
public:
	Position(int row = 0, int col = 0);
	~Position();
	int getRow() const { return _row; }
	int getCol() const { return _col; }
	void setRow(int row) { _row = row; }
	void setCol(int col) { _col = col; }
	bool operator==(const Position& o);
	
};

std::ostream& operator<< (std::ostream& o, const Position& p);

