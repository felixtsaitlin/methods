#include "Maze2dImpl.h"

using namespace std;
Maze2dImpl::Maze2dImpl()
{
}

Maze2dImpl::~Maze2dImpl()
{
}

Maze2dImpl::Maze2dImpl(vector<int> dataVec)
{
	_height = dataVec[0];//h
	_width = dataVec[1];//w
	_startPos.setRow(dataVec[2]);//s r
	_startPos.setCol(dataVec[3]);//s c
	_endPos.setRow(dataVec[4]);//e r
	_endPos.setCol(dataVec[5]);//e c

	//create grid
	_grid = new int*[_height];

	for (int i = 0; i < _height; i++)
	{
		_grid[i] = new int[_width];
	}

	int r = 0;
	int c = 0;


	for (int i = 6; i < dataVec.size(); i++)
	{
		_grid[r][c] = dataVec[i];
		c++;
		if (c == _width)
		{
			c = 0;
			r++;
		}
	}
}

bool Maze2dImpl::isBlocked(Position pos, CellDirection dir) const
{
	if (dir == CDUp)
	{
		return (_grid[pos.getRow() - 1][pos.getCol()] == 0);
	}
	else if (dir == CDRight)
	{
		return (_grid[pos.getRow()][pos.getCol() + 1] == 0);
	}
	else if (dir == CDDown)
	{
		return (_grid[pos.getRow() + 1][pos.getCol()] == 0);
	}
	else// (dir == CDLeft)
	{
		return (_grid[pos.getRow()][pos.getCol() - 1] == 0);
	}
}

vector<Position> Maze2dImpl::getPossibleMoves(Position p) const
{
	vector<Position> nVec;
	int r = p.getRow();
	int c = p.getCol();
	if (_grid[r][c] == PATH)
	{
		if (r - 1 >= 0 && _grid[r - 1][c] == PATH)
		{
			nVec.push_back(Position(r - 1, c));
		}
		if (c - 1 >= 0 && _grid[r][c - 1] == PATH)
		{
			nVec.push_back(Position(r, c - 1));
		}
		if (r + 1 < _height && _grid[r + 1][c] == PATH)
		{
			nVec.push_back(Position(r + 1, c));
		}
		if (c + 1 < _width && _grid[r][c + 1] == PATH)
		{
			nVec.push_back(Position(r, c + 1));
		}
	}
	return nVec;
}

bool Maze2dImpl::isValidPos(Position pos) const
{
	return (pos.getRow() >= 0 && pos.getRow() < _height && pos.getCol() >= 0 && pos.getCol() < _width);
}

vector<int> Maze2dImpl::getData() const
{
	vector<int> vec;
	vec.push_back(_height);//h
	vec.push_back(_width);//w
	vec.push_back(_startPos.getRow());//s r
	vec.push_back(_startPos.getCol());//s c
	vec.push_back(_endPos.getRow());//e r
	vec.push_back(_endPos.getCol());//e c

	for (int i = 0; i < _height; i++)
	{
		for (int j = 0; j < _width; j++)
		{
			vec.push_back(_grid[i][j]);
		}
	}
	return vec;
}

int Maze2dImpl::getHeight() const
{
	return _height;
}

int Maze2dImpl::getWidth() const
{
	return _width;
}

const int** Maze2dImpl::getOneZeroGrid() const
{
	return (const int **)_grid;
}

Position Maze2dImpl::getStartPosition() const
{
	return _startPos;
}

Position Maze2dImpl::getEndPosition() const
{
	return _endPos;
}

unsigned char CELL(int mask)
{
	return ' ';

	//the next code is for debugging
	mask = mask & 0x0F;

	if (mask < 10)
		return mask + '0';
	else
		return (mask % 10) + 'a';
}

void Maze2dImpl::print(ostream& o) const
{
	for (int i = 0; i < _height; i++)
	{
		for (int j = 0; j < _width; j++)
		{
			if (i == _startPos.getRow() && j == _startPos.getCol())
				o.put(234);
			else if (i == _endPos.getRow() && j == _endPos.getCol())
				o.put(157);
			else if (_grid[i][j] == 1)
				o << " ";
			else
				o << _grid[i][j];
		}
		o << endl;
	}
}




