#pragma once
#include <stack>
#include <vector>
#include <string>
#include "Position.h"
#include "Maze2dImpl.h"

class MyMaze2d : public Maze2dImpl
{
private:
	enum
	{
		PATH_UP = 0x01,
		PATH_RIGHT = 0x02,
		PATH_DOWN = 0x04,
		PATH_LEFT = 0x08,
		CELL_VISITED = 0x10
	};

	void fillWallsRec(std::stack<Position>& posStack, int** maze, int& nVisited, int height, int width);
public:
	MyMaze2d(std::vector<int> data);
	MyMaze2d(int width, int height);
	~MyMaze2d();
	void generateOneZeroGrid(int** bitWallsMap, int bitWallsH, int bitWallsW);
};

