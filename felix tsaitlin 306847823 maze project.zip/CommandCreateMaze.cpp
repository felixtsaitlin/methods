#include "CommandCreateMaze.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;
CommandCreateMaze::CommandCreateMaze(Model* m, View* v)
	:Command(m,v)
{
}

CommandCreateMaze::~CommandCreateMaze()
{
}

void CommandCreateMaze::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string name = ((MyView*)_v)->getStr();
	((MyView*)_v)->put("Please insert maze height:\n");
	int height = ((MyView*)_v)->getInt();
	((MyView*)_v)->put("Please insert maze width:\n");
	int width = ((MyView*)_v)->getInt();
	_m->generateMaze(name, height, width);
}

