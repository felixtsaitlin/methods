#include "CommandSaveToFile.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;
CommandSaveToFile::CommandSaveToFile(Model* m, View* v)
	:Command(m, v)
{
}

CommandSaveToFile::~CommandSaveToFile()
{
}

void CommandSaveToFile::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string mazeName = ((MyView*)_v)->getStr();
	((MyView*)_v)->put("Please insert file name:\n");
	string  fileName = ((MyView*)_v)->getStr();
	_m->saveMaze(mazeName,fileName);
}

