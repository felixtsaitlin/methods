#pragma once

#include <iostream>
#include "Model.h"
#include "View.h"

//base class for all user commands
class Command
{
protected:
	Model* _m;
	View* _v;
public:
	Command(Model* m, View* v);
	~Command();
	virtual void execute() = 0;
};

