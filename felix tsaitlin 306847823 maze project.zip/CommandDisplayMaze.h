#pragma once
#include "Command.h"

class CommandDisplayMaze : public Command
{
public:
	CommandDisplayMaze(Model* m, View* v);
	~CommandDisplayMaze();
	virtual void execute() override;
};

