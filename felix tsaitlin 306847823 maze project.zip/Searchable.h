#pragma once

//interface for seacchable problem
#include <vector>
#include "State.h"

class Searchable
{
protected:
	std::vector<State> _allVertexesVec;
public:
	virtual State getStartState() const = 0;
	virtual State getGoalState() const = 0;
	//gets all moves from this state
	virtual std::vector<State> getAllPossibleStates(State& s) const = 0;
	std::vector<State> getAllVertexes() { return _allVertexesVec; }
};

