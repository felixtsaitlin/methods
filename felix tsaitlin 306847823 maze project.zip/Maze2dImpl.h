#pragma once
#include <string>
#include <iostream>
#include <vector>
#include "Position.h"

enum CellDirection
{
	CDUp = 0x01,
	CDRight = 0x02,
	CDDown = 0x04,
	CDLeft = 0x08
};

#define WALL 0
#define PATH 1

class Maze2dImpl
{
protected:
	int**		_grid;
	Position	_startPos;
	Position	_endPos;
	int			_width;
	int			_height;
public:
	Maze2dImpl();
	Maze2dImpl(std::vector<int> dataVec);
	virtual ~Maze2dImpl();
	virtual Position getStartPosition() const;
	virtual Position getEndPosition() const;
	virtual std::vector<Position> getPossibleMoves(Position p) const;
	virtual void print(std::ostream& o) const;
	virtual int getHeight() const;
	virtual int getWidth() const;
	virtual bool isBlocked(Position pos, CellDirection dir) const;
	virtual bool isValidPos(Position pos) const;
	virtual const int** getOneZeroGrid() const;
	virtual std::vector<int> getData() const;
};

