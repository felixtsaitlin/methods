#pragma once

#include "View.h"
#include "Model.h"
#include "Command.h"
#include "Observer.h"
#include "Observable.h"

//base class for controller in MVC
class Controller :public Observer, public Observable
{
protected:
	View* _view;
	Model* _model;
public:
	Controller(Model* model, View* view);
	~Controller();
	virtual Command* getCommand(std::string cmdName) = 0;
	virtual std::vector<std::string> getCommandNames() = 0;

};

