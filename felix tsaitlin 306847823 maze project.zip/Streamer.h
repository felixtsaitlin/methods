#pragma once
#include <ostream>
//interface for streaming adapters for CLI view
class Streamer
{
public:
	virtual void stream(std::ostream& o) const = 0;
};

std::ostream& operator<<(std::ostream& o, const Streamer& s);
