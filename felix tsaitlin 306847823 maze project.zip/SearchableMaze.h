#pragma once
#include "Searchable.h"
#include "Maze2d.h"

class SearchableMaze : public Searchable
{
private:
	Maze2d* _maze;
	void createAllVertexes();
public:
	SearchableMaze(Maze2d& maze);
	~SearchableMaze();

	virtual State getStartState() const override;
	virtual State getGoalState() const override;
	virtual std::vector<State> getAllPossibleStates(State& s) const override;
};

