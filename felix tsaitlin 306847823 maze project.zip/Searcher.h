#pragma once
#include "Searchable.h"
#include "Solution.h"

//base class for algorithm implementing searcher pattern
class Searcher
{
protected:
	int _numNodesEveluated;
public:
	Searcher();
	virtual Solution search(const Searchable& s) = 0;
	int getNumberOfNodesEvaluated() const { return _numNodesEveluated; }
};

