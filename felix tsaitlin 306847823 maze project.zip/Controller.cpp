#include "Controller.h"

Controller::Controller(Model* model, View* view)
	:_model(model),_view(view)
{
	if (_view)
		_view->setController(this);
	if (_model)
		_model->registerObserver(this);
}

Controller::~Controller()
{
}
