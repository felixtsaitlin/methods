#include "Streamer.h"

using namespace std;

ostream& operator<<(ostream& o, const Streamer& s)
{
	s.stream(o);
	return o;
}



