#include "Observable.h"
#include "Observer.h"

using namespace std;
Observable::Observable()
{
}

Observable::~Observable()
{
}

void Observable::registerObserver(Observer* o)
{
	_observers.push_back(o);
}

void Observable::unregisterObserver(Observer* o)
{
	for (int i = 0; i < _observers.size(); i++)
	{
		if (_observers[i] == o)
			_observers[i] = nullptr;
	}
}

void Observable::notifyObservers(string message)
{
	for (int i = 0; i < _observers.size(); i++)
	{
		if(_observers[i] != nullptr)
			_observers[i]->update(message);
	}
}