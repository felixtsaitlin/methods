#pragma once
#pragma warning(disable: 4290)

#include <vector>
#include <iostream>
#include <fstream>
#include "Maze2d.h"

class MazeCompression
{
private:
	std::vector<unsigned char> compress(std::vector<int> dataVec) const;
	std::vector<int> decompress(std::vector<unsigned char> compDataVec) const;
public:
	MazeCompression();
	~MazeCompression();
	void save(std::ofstream& file, const Maze2d& m) const throw(std::string);
	Maze2d* read(std::ifstream& file) const throw(std::string);
};

