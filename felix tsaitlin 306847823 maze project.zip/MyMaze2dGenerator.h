#pragma once
#include "Maze2dGenerator.h"
class MyMaze2dGenerator : public Maze2dGenerator
{
public:
	MyMaze2dGenerator();
	~MyMaze2dGenerator();
	virtual Maze2d generate(int w, int h) override;
};

