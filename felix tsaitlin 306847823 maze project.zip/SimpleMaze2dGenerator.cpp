#include "SimpleMaze2dGenerator.h"
#include "SimpleMaze2d.h"

SimpleMaze2dGenerator::SimpleMaze2dGenerator()
{
}

SimpleMaze2dGenerator::~SimpleMaze2dGenerator()
{
}

Maze2d SimpleMaze2dGenerator::generate(int w,int h)
{
	//TODO implement for a specific maze
	return new SimpleMaze2d(w,h);
}
