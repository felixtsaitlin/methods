#pragma once

#include <iostream>
#include "Observer.h"

class Controller;
//base class for view in MVC
class View :public Observer
{
protected:
	Controller* _controller;
public:
	View();
	virtual void start() = 0;
	void setController(Controller* controller);
};

