#pragma once

#include<vector>
#include "Observable.h"
#include "Maze2d.h"
#include "Solution.h"

//base class for model in MVC
class Model : public Observable
{
public:
	Model();
	~Model();

	virtual std::vector<std::string> dirContents(std::string path) = 0;
	virtual void generateMaze(std::string name, int height, int width) = 0;
	virtual Maze2d* displayMaze(std::string name) = 0;
	virtual void saveMaze(std::string mazeName, std::string fileName) = 0;
	virtual void loadMaze(std::string fileName, std::string mazeName) = 0;
	virtual int mazeSize(std::string name) = 0;
	virtual int fileSize(std::string name) = 0;
	virtual void SolveMaze(std::string name, std::string algo) = 0;
	virtual Solution* displaySolution(std::string name) = 0;
	virtual void ExitClean() = 0;
};

