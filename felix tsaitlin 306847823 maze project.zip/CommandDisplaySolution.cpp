#include "CommandDisplaySolution.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;

CommandDisplaySolution::CommandDisplaySolution(Model* m, View* v)
	:Command(m, v)
{
}

CommandDisplaySolution::~CommandDisplaySolution()
{
}

void CommandDisplaySolution::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string mazeName = ((MyView*)_v)->getStr();
	Solution* sol = _m->displaySolution(mazeName);
	if (sol)
	{
		((MyView*)_v)->getOstream() << *sol << endl;
	}
}

