#include "IAstar.h"

IaStar::IaStar(const IAstarHeuristic& h)
	:_h(h)
{
}
