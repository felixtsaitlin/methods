#pragma once
#include "Maze2dGenerator.h"
class SimpleMaze2dGenerator : public Maze2dGenerator
{
public:
	SimpleMaze2dGenerator();
	~SimpleMaze2dGenerator();
	virtual Maze2d generate(int w, int h) override;
};

