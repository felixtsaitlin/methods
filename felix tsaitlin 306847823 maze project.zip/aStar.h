#pragma once
#include <iostream>
#include <vector>
#include <stack>
#include <set>

#include "IAstar.h"

class AStar: public IaStar
{
protected:
	// A structure to hold the neccesary parameters 
	struct cell
	{
		// Row and Column index of its parent 
		// Note that 0 <= i <= ROW-1 & 0 <= j <= COL-1 
		int parent_i, parent_j;
		// f = g + h 
		double f, g, h;
	};

	// Creating a shortcut for int, int pair type 
	typedef std::pair<int, int> Pair;

	// Creating a shortcut for pair<int, pair<int, int>> type 
	typedef std::pair<double, std::pair<int, int>> pPair;
private:
	int _rows;
	int _cols;
	const int** _grid;
	bool _foundDest;
	bool isValid(int row, int col);
	bool isUnBlocked(int row, int col);
	bool isDestination(int row, int col, Pair dest);
	double calculateHValue(int row, int col, Pair dest);
	std::vector<Position> tracePath(cell** _cellDetails, Pair dest,bool bPrint = false);
	std::vector<Position> aStarSearch(Pair src, Pair dest);
public:
	AStar(const IAstarHeuristic& h);
	virtual Solution search(const Maze2d& maze) override;
	virtual Solution search(const Searchable& s) override;
};

