#pragma once
#include "Maze2dImpl.h"
class SimpleMaze2d : public Maze2dImpl
{
public:
	SimpleMaze2d(int h, int w);
	~SimpleMaze2d();
};

