#include <iostream>
#include "Maze2d.h"

using namespace std;

Maze2d::Maze2d()//for use of maze in stl map
:_pMaze(nullptr)
{
}

Maze2d::Maze2d(Maze2dImpl* pMaze)
{
	_pMaze = pMaze;
}

Maze2d::Maze2d(vector<int> dataVec)
{
	_pMaze = new Maze2dImpl(dataVec);
}

Position Maze2d::getStartPosition() const
{
	return _pMaze->getStartPosition();
}

Position Maze2d::getEndPosition() const
{
	return _pMaze->getEndPosition();
}

vector<Position> Maze2d::getPossibleMoves(Position p) const
{
	return _pMaze->getPossibleMoves(p);

}

int Maze2d::getHeight() const
{
	return _pMaze->getHeight();
}

int Maze2d::getWidth() const
{
	return _pMaze->getWidth();

}

bool Maze2d::isBlocked(Position pos, CellDirection dir) const
{
	return _pMaze->isBlocked(pos,dir);
}

bool Maze2d::isUnBlocked(Position pos, CellDirection dir) const
{
	return !(_pMaze->isBlocked(pos,dir));
}

bool Maze2d::isValidPos(Position pos) const
{
	return _pMaze->isValidPos(pos);
}

std::ostream& operator<<(std::ostream& o, const Maze2d& m)
{
	m._pMaze->print(o);

	return o;
}

const int** Maze2d::getOneZeroGrid() const
{
	return _pMaze->getOneZeroGrid();
}

vector<int> Maze2d::getData() const
{
	return _pMaze->getData();
}


