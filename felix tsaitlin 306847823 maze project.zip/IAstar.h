#pragma once
#include <vector>
#include "Maze2d.h" 
#include "IAstarHeuristic.h"
#include "Solution.h"
#include "Searcher.h"

class IaStar : public Searcher
{
protected:
	const IAstarHeuristic& _h;
public:
	IaStar(const IAstarHeuristic& h);
 	virtual Solution search(const Maze2d& maze) = 0;
};
