#include "View.h"
#include "Controller.h"

View::View()
	:_controller(nullptr)
{
}

void View::setController(Controller* controller)
{
	_controller = controller;
	if (_controller)
		_controller->registerObserver(this);
}