#pragma once
#include "Command.h"
class CommandLoadFromFile : public Command
{
public:
	CommandLoadFromFile(Model* m, View* v);
	~CommandLoadFromFile();
	virtual void execute() override;
};

