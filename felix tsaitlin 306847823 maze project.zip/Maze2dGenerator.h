#pragma once
#include "IMaze2dGenerator.h"

class Maze2dGenerator : public IMaze2dGenerator
{
public:
	std::string measureAlgorithmTime();// part a - 2b
	//virtual Maze2d generate() ; // part a - 2a
};

