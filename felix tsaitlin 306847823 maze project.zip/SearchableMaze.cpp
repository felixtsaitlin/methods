#include "SearchableMaze.h"

using namespace std;
SearchableMaze::SearchableMaze(Maze2d& maze)
	:_maze(&maze)
{
	createAllVertexes();
}

SearchableMaze::~SearchableMaze()
{
}

void SearchableMaze::createAllVertexes()
{
	const int** grid = _maze->getOneZeroGrid();
	for (int r = 0; r < _maze->getHeight(); r++)
	{
		for (int c = 0; c < _maze->getWidth(); c++)
		{
			State currState(Position(r, c), 0, nullptr);

			vector<State> statesVec = getAllPossibleStates(currState);

			for (auto s: statesVec)
			{
				_allVertexesVec.push_back(s);
			}
		}
	}

	//TODO - remove test prints
	/*
	cout << "DA MAZE" << endl << *_maze << endl;
	cout << "ALL VERTEXES" << endl;
	for (int i = 0; i < _allVertexesVec.size(); i++)
	{
		cout << "from " << *(_allVertexesVec[i].getCameFrom()) << " to " << _allVertexesVec[i] << " | ";
	}
	*/
}

State SearchableMaze::getStartState() const
{
	return State (_maze->getStartPosition(),0,nullptr);
}

State SearchableMaze::getGoalState() const
{
	return State (_maze->getEndPosition(),0,nullptr);
}

std::vector<State> SearchableMaze::getAllPossibleStates(State& s) const
{
	vector<Position> posVec = _maze->getPossibleMoves(s.getState());
	vector<State> stateVec;

	for (int i = 0; i < posVec.size(); i++)
	{
		stateVec.push_back(State(posVec[i], 0, new State(s.getState(),s.getCost(),nullptr)));
	}
	return stateVec;
};
