#pragma once
#include "Command.h"
class CommandSolveMaze :public Command
{
public:
	CommandSolveMaze(Model* m, View* v);
	~CommandSolveMaze();
	virtual void execute() override;
};

