#include "State.h"

using namespace std;

State::State(Position state, int cost, State* pCameFrom)
	: _state(state), _cost(cost), _cameFrom(pCameFrom)
{
}

State::~State() 
{
}

ostream& State::write(ostream& o) const
{
	o << _state << " ";
	return o;
}

State* State::getCameFrom() const
{
	return _cameFrom;
}

int State::getCost() const
{
	return _cost;
}

Position State::getState() const
{
	return _state;
}

ostream& operator<<(ostream& o, const State& s)
{
	s.write(o);
	return o;
}
