#include "CommandSolveMaze.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;
CommandSolveMaze::CommandSolveMaze(Model* m, View* v)
	:Command(m, v)
{
}

CommandSolveMaze::~CommandSolveMaze()
{
}

void CommandSolveMaze::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string mazeName = ((MyView*)_v)->getStr();	
	((MyView*)_v)->put("Please insert algo name:\n");
	string algoName = ((MyView*)_v)->getStr();
	_m->SolveMaze(mazeName, algoName);
}

