#pragma warning(disable: 4290)
#include "MazeCompression.h"
#include "MyMaze2d.h"

using namespace std;

MazeCompression::MazeCompression()
{
}

MazeCompression::~MazeCompression()
{
}

/*
Maze2d& MazeCompression::makeMaze() const
{

}
*/
void MazeCompression::save(std::ofstream& file, const Maze2d& m) const throw(string)
{
	try
	{
		if (file.good())
		{
			vector<unsigned char> v = compress(m.getData());
			for (int i = 0; i < v.size(); i++)
			{
				file.write((const char*)&v[i], sizeof(v[i]));
			}
		}
		else
			throw "something went wrong";
	}
	catch (const char* str)
	{
		throw str;
	}
	catch (...)
	{
		throw "Cannot save to file";
	}
}
Maze2d* MazeCompression::read(std::ifstream& file) const  throw(string)
{
	try
	{
		if (file.good())
		{
			vector<unsigned char> v;
			unsigned char uc;
			while (!file.eof() && file.good())
			{
				file.read((char*)&uc, 1);
				if (!file.eof())
					v.push_back(uc);
			}
			
			Maze2d* m = new Maze2d(decompress(v));
			return m;
		}
		else
			throw "something went wrong";
	}
	catch (const char* str)
	{
		throw str;
	}
	catch (...)
	{
		throw "Cannot read from file";
	}
}
//height, width ,start row, start col, end row, end col, 0/1 of each cell
std::vector<unsigned char> MazeCompression::compress(std::vector<int> dataVec) const
{
	std::vector<unsigned char> res;
	res.push_back((unsigned char)dataVec[0]);//height
	res.push_back((unsigned char)dataVec[1]);//width
	res.push_back((unsigned char)dataVec[2]);//start row
	res.push_back((unsigned char)dataVec[3]);//start col
	res.push_back((unsigned char)dataVec[4]);//end row
	res.push_back((unsigned char)dataVec[5]);//end col

	unsigned char count = 1;
	int val = dataVec[6];
	for (int i = 7; i < dataVec.size(); i++)
	{
		if (dataVec[i] == val)
			count++;
		else
		{
			res.push_back(count);
			res.push_back((unsigned char)val);
			count = 1;
			val = dataVec[i];
		}
	}

	res.push_back(count);
	res.push_back((unsigned char)val);

	return res;
}

std::vector<int> MazeCompression::decompress(std::vector<unsigned char> compDataVec) const
{
	std::vector<int> res;
	res.push_back((unsigned char)compDataVec[0]);//height
	res.push_back((unsigned char)compDataVec[1]);//width
	res.push_back((unsigned char)compDataVec[2]);//start roe
	res.push_back((unsigned char)compDataVec[3]);//start col
	res.push_back((unsigned char)compDataVec[4]);//end row
	res.push_back((unsigned char)compDataVec[5]);//end col

	for (int i = 6; i < compDataVec.size(); i+=2)
	{
		int count = (int)compDataVec[i];
		int val = (int)compDataVec[i + 1];
		for (int j = 0; j < count; j++)
		{
			res.push_back(val);
		}
	}

	return res;
}