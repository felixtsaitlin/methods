#include "Maze2dGenerator.h"

std::string Maze2dGenerator::measureAlgorithmTime()
{
	return "stam";
}
