#pragma once
#include "Command.h"

class CommandCreateMaze : public Command
{
public:
	CommandCreateMaze(Model* m, View* v);
	~CommandCreateMaze();
	virtual void execute() override;
};

