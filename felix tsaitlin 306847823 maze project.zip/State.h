#pragma once

#include <string>
#include "position.h"

class State
{
public:
	State(Position state, int cost, State* pCameFrom);
	//State(const State& o) = delete;
	~State();
	bool operator == (State& s) { return (this->_state == s._state); }
	State* getCameFrom() const;
	int getCost() const;
	Position getState() const;
	std::ostream& write(std::ostream& o) const;
private:
	Position _state;
	State* _cameFrom;
	int _cost;
};

std::ostream& operator<<(std::ostream& o, const State& s);






