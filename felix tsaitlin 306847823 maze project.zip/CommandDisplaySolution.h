#pragma once
#include "Command.h"

class CommandDisplaySolution : public Command
{
public:
	CommandDisplaySolution(Model* m, View* v);
	~CommandDisplaySolution();
	virtual void execute() override;
};

