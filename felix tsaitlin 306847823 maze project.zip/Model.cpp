#include "Model.h"

Model::Model()
{
}

Model::~Model()
{
}
