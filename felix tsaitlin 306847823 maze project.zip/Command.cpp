#include "Command.h"

Command::Command(Model* m, View* v)
:_m(m),_v(v)
{
}

Command::~Command()
{
}
