#pragma once

#include<map>
#include "Model.h"
#include "Solution.h"
#include "Maze2dGenerator.h"
#include "MazeCompression.h"
#include "aStar.h"

class MyModel : public Model
{
private:
	const int MAX_MAZE_WIDTH = 50;
	const int MAX_MAZE_HEIGHT = 30;
	const int MIN_MAZE_WIDTH = 5;
	const int MIN_MAZE_HEIGHT = 5;
protected:
	std::map<std::string, Maze2d> _mazesMap;
	Maze2dGenerator* _mazeGenerator;
	MazeCompression* _mazeCompression;
	std::vector<std::string> _filenamesVec;
	std::map<std::string, Solution> _solutionsMap;
	IaStar* _aStar;
	IAstarHeuristic* _aStarH;
	
public:
	MyModel();
	~MyModel();

	virtual std::vector<std::string> dirContents(std::string path) override;
	virtual void generateMaze(std::string name, int height, int width) override;
	virtual Maze2d* displayMaze(std::string name) override;
	virtual void saveMaze(std::string mazeName, std::string fileName) override;
	virtual void loadMaze(std::string fileName, std::string mazeName) override;
	virtual int mazeSize(std::string name) override;
	virtual int fileSize(std::string name) override;
	virtual void SolveMaze(std::string name, std::string algo) override;
	virtual Solution* displaySolution(std::string name) override;
	virtual void ExitClean() override;
};

