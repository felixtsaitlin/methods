#include "IAstarHeuristic.h"



double AstarAirDistHeuristic::calc(const Position& src, const Position& dst) const
{
	return (double) ( sqrt(pow(src.getRow() - dst.getRow(),2) + pow(src.getCol() - dst.getCol(), 2)) );
}

double AstarManhattanHeuristic::calc(const Position& src, const Position& dst) const
{
	return (double) ( abs(src.getRow() - dst.getRow()) + abs(src.getCol() - dst.getCol()) ) ;
}


