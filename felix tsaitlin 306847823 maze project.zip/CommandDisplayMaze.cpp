#include "CommandDisplayMaze.h"
#include "Maze2d.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;
CommandDisplayMaze::CommandDisplayMaze(Model* m, View* v)
	:Command(m, v)
{
}

CommandDisplayMaze::~CommandDisplayMaze()
{
}

void CommandDisplayMaze::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string name = ((MyView*)_v)->getStr();
	Maze2d* m = _m->displayMaze(name);
	((MyView*)_v)->displayMaze(m);
}

