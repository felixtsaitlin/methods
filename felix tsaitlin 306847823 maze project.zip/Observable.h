#pragma once

#include <vector>
#include <string>

class Observer;
class Observable
{
protected:
	std::vector<Observer*> _observers;
public:
	Observable();
	~Observable();
	void registerObserver(Observer* o);
	void unregisterObserver(Observer* o);
	void notifyObservers(std::string message);
};

