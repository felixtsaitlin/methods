#pragma once
#include <map>
#include <string>
#include "View.h"
#include "Maze2d.h"
#include <memory>

class MyView : public View
{
protected:
	std::istream& _is;
	std::ostream& _os;
	void showCommands(std::vector<std::string> commandsVec);
public:
	MyView(std::istream& is, std::ostream& os);
	~MyView();
	virtual void start() override;

	virtual void update(std::string message) override;
	void put(std::string data);
	std::string getStr();
	int getInt();
	std::ostream& getOstream();

	void displayMaze(Maze2d* m) const;
};



