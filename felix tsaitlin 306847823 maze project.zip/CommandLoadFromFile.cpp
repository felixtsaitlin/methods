#include "CommandLoadFromFile.h"
#include "MyModel.h"
#include "MyView.h"

using namespace std;
CommandLoadFromFile::CommandLoadFromFile(Model* m, View* v)
	:Command(m, v)
{
}

CommandLoadFromFile::~CommandLoadFromFile()
{
}

void CommandLoadFromFile::execute()
{
	((MyView*)_v)->put("Please insert maze name:\n");
	string mazeName = ((MyView*)_v)->getStr();
	((MyView*)_v)->put("Please insert file name:\n");
	string  fileName = ((MyView*)_v)->getStr();
	_m->loadMaze(fileName, mazeName);
}

