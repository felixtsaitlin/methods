#include "MyController.h"
#include "CommandCreateMaze.h"
#include "CommandDisplayMaze.h"
#include "CommandSolveMaze.h"
#include "CommandSaveToFile.h"
#include "CommandLoadFromFile.h"
#include "CommandSolveMaze.h"
#include "CommandDisplaySolution.h"

using namespace std;

MyController::MyController(Model* model, View* view)
	:Controller(model,view)
{
	//add all commands to the menu
	_commandsMap["Create"] = new CommandCreateMaze(_model, _view);
	_commandsMap["Display"] = new CommandDisplayMaze(_model, _view);
	_commandsMap["Solve"] = new CommandSolveMaze(_model, _view);
	_commandsMap["Save"] = new CommandSaveToFile(_model, _view);
	_commandsMap["Load"] = new CommandLoadFromFile(_model, _view);
	_commandsMap["DisplaySolution"] = new CommandDisplaySolution(_model, _view);
}

Command* MyController::getCommand(string cmdName)
{
	if (_commandsMap.find(cmdName) != _commandsMap.end())
		return _commandsMap[cmdName];
	else
		return nullptr;
}

MyController::~MyController()
{
	//delete all the commands
	map<string, Command*>::iterator itr = _commandsMap.begin();
	if (itr != _commandsMap.end())
	{
		delete itr->second;
	}
}

void MyController::update(std::string message)
{
	//once a message from the model received - update the view
	for (int i = 0; i < _observers.size(); i++)
	{
		_observers[i]->update(message);
	}
}

vector<string> MyController::getCommandNames()
{
	vector<string> vec;
	map<string, Command*>::iterator itr = _commandsMap.begin();
	while (itr != _commandsMap.end())
	{
		vec.push_back(itr->first);
		++itr;
	}
	return vec;
}

