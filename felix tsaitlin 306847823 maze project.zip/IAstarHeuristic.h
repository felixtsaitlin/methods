#pragma once
#include "Position.h"
class IAstarHeuristic
{
public:
	virtual double calc(const Position& src, const Position& dst) const = 0;
};

class AstarAirDistHeuristic : public IAstarHeuristic
{
public:
	virtual double calc(const Position& src, const Position& dst) const override;
};

class AstarManhattanHeuristic : public IAstarHeuristic
{
public:
	virtual double calc(const Position& src, const Position& dst) const override;
};

